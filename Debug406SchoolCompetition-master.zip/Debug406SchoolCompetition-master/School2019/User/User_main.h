//真正的头文件
#ifndef USER_MAIN_H_
#define USER_MAIN_H_

void User_main(void);

#endif